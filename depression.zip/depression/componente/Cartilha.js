import React from 'react';
//importando os componentes View e Text
import { View, Text, Image, ScrollView } from 'react-native';

// função
export default function Cartilha() {
return (
  <ScrollView>
<Text>
<b>Olá jovens da Unibra!!!!</b><br/>
<b>Primeiramente, Bom Dia!</b><br/>
<b>Segundamente, se vocês tem depressão,<br/>
 é só não ter!</b><br/>
 <Image source={require('../assets/sa2.jpg')} />
 <b>APRENDEMOS SEMPRE:<br/></b> 
“A vida não é para quem sabe viver, a vida é para aqueles que demonstram, sem vergonha, tudo o que se passa dentro de si, ou seja, é para quem tem coragem! Você é corajoso, expôs suas fraquezas, suas inseguranças, sua depressão, você pediu ajuda, você é humano! Mesmo achando que nada mais tem sentido, tudo tem um propósito e nós aprendemos tanto no amor, quanto na dor… não deixe de demonstrar pois pessoas para te darem as mãos não irão faltar!”
</Text>
</ScrollView>
)
}