import { StyleSheet, Text, TextInput, View, Image,
TouchableOpacity, Alert,ScrollView } from "react-native";
// Importando o componente Cartilha.
import Cartilha from './componente/Cartilha'
export default function App() {
return (
<View style={{flex:1, backgroundColor:'gold'}}>
<Cartilha/>
</View>
);
}
const styles = StyleSheet.create({
container: {
flex: 2,
backgroundColor: "#228B22",
alignItems: "center",
justifyContent: "center",
padding: 20,

},
});
